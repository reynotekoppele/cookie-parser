const { expect, jest } = require("@jest/globals");
const Cookies = require("../src/cookie-parser");

let __cookies = [];
Object.defineProperty(window.document, "cookie", {
  get: (n) => {
    return n
      ? __cookies.find(({ name }) => name === n)
      : __cookies[__cookies.length - 1];
  },
  set: (v) => {
    __cookies.push(
      Object.fromEntries(v.split(";").map((item) => item.split("=")))
    );
  },
});

/* ----- Creating ----- */
describe("Creating cookies", () => {
  it("Basic cookie", () => {
    const result = {
      "max-age": "86400",
      name: "value",
      path: "/",
      samesite: "lax",
    };

    Cookies.set("name", "value");

    expect(document.cookie).toMatchObject(result);
  });

  it("Expires after 7 days", () => {
    const result = {
      "max-age": "604800",
      name: "value",
      path: "/",
      samesite: "lax",
    };

    Cookies.set("name", "value", {
      days: 7,
    });

    expect(document.cookie).toMatchObject(result);
  });

  it("Inside a subdirectory", () => {
    const result = {
      "max-age": "86400",
      name: "value",
      path: "/subdirectory",
      samesite: "lax",
    };

    Cookies.set("name", "value", {
      path: "/subdirectory",
    });

    expect(document.cookie).toMatchObject(result);
  });

  it("Cannot be send to any cross-site browsing contexts", () => {
    const result = {
      "max-age": "86400",
      name: "value",
      path: "/",
      samesite: "strict",
    };

    Cookies.set("name", "value", {
      sameSite: "strict",
    });

    expect(document.cookie).toMatchObject(result);
  });

  it("All of the above combined", () => {
    const result = {
      "max-age": "604800",
      name: "value",
      path: "/subdirectory",
      samesite: "strict",
    };

    Cookies.set("name", "value", {
      days: 7,
      path: "/subdirectory",
      sameSite: "strict",
    });

    expect(document.cookie).toMatchObject(result);
  });

  it("Invalid name", () => {
    expect(() => {
      Cookies.set("", "value");
    }).toThrow('"name" and "value" are required');
  });

  it("Invalid value", () => {
    expect(() => {
      Cookies.set("name", "");
    }).toThrow('"name" and "value" are required');
  });
});

/* ----- Reading ----- */

// test("Read a cookie", () => {
//   Cookies.set("name", "value");
//   const value = Cookies.get("name");
//   console.log(value);

//   expect(value).toBe("value");
// });

// test("Read non existing cookie", () => {
//   const value = Cookies.get("not exist");

//   expect(value).toBe(undefined);
// });

// test("Read all cookies", () => {
//   Cookies.set("name", "value");
//   console.log(document.cookie);
//   const cookies = Cookies.get();

//   expect(cookies).toBe([["name", "value"]]);
// });

/* ----- Deleting ----- */
// test("Delete a cookie", () => {
//   Cookies.set("name", "value");
//   Cookies.delete("name");

//   expect(document.cookie).toBe(undefined);
// });
